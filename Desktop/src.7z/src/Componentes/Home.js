import React from 'react';
import { Button }from 'react-bootstrap';
import '../Estilo.css';
import { Link } from "react-router-dom";

class Home extends React.Component {
    render() {
        return(
            <div>
                <Link to="/"><Button variant="primary">Sair</Button></Link>
            </div>
        );
    }


}

export default Home;