import React from 'react';
import { Button } from 'react-bootstrap';
import { Link } from "react-router-dom";
class Login extends React.Component {
    render() {
        return(
            <div>
                <Link to="/home"><Button style={styles.loginButton} variant="primary">Entrada</Button></Link>
                
            </div>
        );
    }


}
var styles = {
    loginButton:{
        color:"black"
    },
}

export default Login;